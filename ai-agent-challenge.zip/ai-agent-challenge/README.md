# ai-agent-challenge
Coding agent challenge which write custom parsers for Bank statement PDF.
